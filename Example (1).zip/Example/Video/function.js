var g_iCutType = "1";
var g_iCamIdx = "0";
var g_bIsIE = false;
var g_iAngle = 0;
var g_fileList = "";
var g_timer = null;
var g_iAutoPreCode = "0";

/////////////////////////// 浏览器类型 ///////////////////////////

function BrowserType()
{
	var userAgent = navigator.userAgent; //取得浏览器的userAgent字符串
	if (userAgent.indexOf("Firefox") > -1) 
		return "Firefox";
	if (userAgent.indexOf("Chrome") > -1)
		return "Chrome";

	return "IE";
}

function IsIE()
{
	if (BrowserType() == "IE")
		return true;
	else
		return false;
}

/////////////////////////// 旋转 ///////////////////////////

function Rotate()
{
	if(g_bIsIE) //ie浏览器
	{
		g_iAngle = showVideoOcx.GetVideoRotate() + 90;
		g_iAngle = g_iAngle % 360;
		showVideoOcx.SetVideoRotate(g_iAngle);
	}
	else
	{
		g_iAngle += 90;
		g_iAngle = g_iAngle % 360;
		//$("#img_video_preview").rotate(90); 
		$('.xform').each(function(idx,el) {
			el.className = "xform x" + "-rotated-" + g_iAngle;
		});	
		if (g_iAngle % 180) {
			$('.xform-p').addClass('rotated');
		} else {
			$('.xform-p').removeClass('rotated');
		}		
	}
}

/////////////////////////// 初始化、卸载 ///////////////////////////

function Init()
{
	g_bIsIE = IsIE();
	if(g_bIsIE) //ie浏览器
	{
		//var ui = document.getElementById("img_video_preview");
		var ui = document.getElementById("noniediv");
		ui.style.display="none";
		ui.style.visibility="hidden";		
		showVideoOcx.StartPreview(0);
	}
	else
	{
		var ui = document.getElementById("ocx_div");
		ui.style.display="none";
		ui.style.visibility="hidden";
	}
	document.getElementById("url_input").value=g_strHTTPServerPath + "/param=get";
	OpenCamera();
	SetAutoCut(true);
}

function Release()
{
	if(g_bIsIE)
	{
		showVideoOcx.StopPreview();
	}
}

/////////////////////////// 初始化、卸载 ///////////////////////////

function OpenCamera()
{
	var camradio = document.getElementsByName("camidx");
	for(i=0; i<camradio.length; i++)
	{
		if(camradio[i].checked)
			g_iCamIdx = camradio[i].value;
	}
	
	if(g_bIsIE) //ie浏览器
	{
		showVideoOcx.StartPreview(g_iCamIdx);
	}
	else
	{
		/// 链接尾部追加tid=时间戳，避免浏览器缓存导致无法正常获取最新的视频流预览
		document.getElementById("img_video_preview").src= g_strHTTPServerPath + "/video=stream&camidx=" + g_iCamIdx.toString() + "&tid=" + (new Date()).valueOf();
	}
	GetResolutionList();
}

/////////////////////////// 分辨率 ///////////////////////////

function GetResolutionList()
{
	var params = "{\"type\": \"resolution\",\"camidx\":\"" + g_iCamIdx.toString() + "\"}";
	var url = g_strHTTPServerPath + "/param=get";

	$.ajax({
		type: "post",  
		url: url,  
		dataType: "json", 
		data: params,
		success: function(data)
		{
			if(data.code != 0)
			{
				document.getElementById("result").innerHTML = "获取分辨率失败，错误代码 = " + data.code + "，错误信息 = " + data.message; 	
			}
			else
			{
				var select = document.getElementById("resolution");
				//获取select下拉框下所有的选项
				while(select.options.length > 0)
				{
					select.remove(i);
				}
				
				var arrays = data.resolution.split("|");
				for(var i=0; i<arrays.length; i++)
				{
					select.options.add(new Option(arrays[i], arrays[i])); 
				}
									
				document.getElementById("result").innerHTML = "获取分辨率成功";
			}  				
		}
	});  
}

function SetResolution()
{
		var select = document.getElementById("resolution");
		var index = select.selectedIndex;		
		var text = select.options[index].text
		var splits = text.split("x");
		
		var params = "{\"resolution\": {\"width\":\"" + splits[0] + "\",\"height\":\"" + splits[1] + "\"},\"camidx\":\"" + g_iCamIdx.toString() + "\"}";
		var url = g_strHTTPServerPath + "/param=set";  

		$.ajax({  
			type: "post",  
			url: url,  
			dataType: "json", 
			data: params,
			success: function(data)
			{				
				document.getElementById("result").innerHTML = "设置分辨率，返回代码 = " + data.code + "，返回信息 = " + data.message; 	
			}
		});  
	}	

/////////////////////////// 切边 ///////////////////////////

function SetAutoCut(bAuto)
{
	g_iCutType = bAuto ? 1 : 0;
	var params = "{\"cutpage\":\"" + (g_iCutType ? "true" : "false") + "\"}";//
	var url = g_strHTTPServerPath + "/param=set";  

	$.ajax({
		type: "post",  
		url: url,  
		dataType: "json", 
		data: params,
		success: function(data)
		{
			document.getElementById("result").innerHTML = "设置参数，返回代码 = " + data.code + "，返回信息 = " + data.message; 					
		}
	});

}

/////////////////////////// 拍照、连拍 ///////////////////////////

function AddImageToList(image)
{
	if(typeof(image.base64) == "undefined")
		return;
	
	/// 首次添加的时，把列表中示意的空图像移除掉
	if(g_fileList == "")
		document.getElementById("image_list_div").innerHTML = "";
	
	if(typeof(image.uuid) != "undefined")
	{
		var uuid = image.uuid;
		if(g_fileList == "")
		{
			g_fileList = "{\"uuid\":\"" + uuid.toString() + "\"}";
		}
		else
		{
			g_fileList = g_fileList + ",{\"uuid\":\"" + uuid.toString() + "\"}";
		}
	}
	
	var strImageList = "<img src=\"data:image/jpg;base64," + image.base64 + "\" class=\"new_image\" />";
	
	if(typeof(image.filepath) != "undefined")
	{
		strImageList += "<br/><a target=_blank href=\"file:///" + image.filepath + "\">点击查看本地文件</a>";
	}
	
	document.getElementById("image_list_div").innerHTML = strImageList + document.getElementById("image_list_div").innerHTML;
}

function GrabImage()
{
	var strStorageInfo = "{ \"xdpi\":\"200\", \"ydpi\":\"200\", \"jpg_quality\":\"60\" }";
	var strImageProcess = "{\"cut_type\":\"" + g_iCutType + "\", \"multi_object\":\"0\", \"rotate\":\"" + g_iAngle.toString() +  "\"}";
	var params = "{\"camidx\":\"" + g_iCamIdx.toString() + "\",\"make_uuid\":\"1\",\"image_storage_info\":" + strStorageInfo + ",\"image_process_info\":" + strImageProcess + "}";
	
	var url = g_strHTTPServerPath + "/video=grabimage";

	$.ajax({
		type: "post",
		url: url,
		dataType: "json",
		data: params,
		success: function(data)
		{
			if(data.code != 0)
			{
				document.getElementById("result").innerHTML = "拍照失败，错误代码：" + data.code + "，返回信息 = " + data.message;
			}
			else
			{
				document.getElementById("result").innerHTML = "图像数量：" + data.image_count;
				var images = data.images;
				var iCount = data.image_count;
				var strImageList = "";
				for(var i = 0; i < iCount; i++)
				{
					AddImageToList(data.images[i]);
				}
			}
		}
	});
}

function BeginTimer()
{
	if(g_timer == null)
	{
		g_timer = setInterval("GetDocumentStatus()", 500);
	}
}

function StartAutoCapture()
{
	document.getElementById("result").innerHTML = "开始自动连拍......";
	var params = "{\"action\": \"start\"}";// 
	var url = g_strHTTPServerPath + "/video=detectdoc";  	

	$.ajax({  
		type: "post",  
		url: url,  
		dataType: "json", 
		data: params,
		success: function(data)
		{
			if(data.code != 0)
			{
				document.getElementById("result").innerHTML = "返回代码 = " + data.code + ",  返回信息 = " + data.message; 
			}
			else
			{
				document.getElementById("result").innerHTML = "返回代码 = " + data.code + ",  返回信息 = " + data.message; 
				BeginTimer();
			}
		}
		});
}

function StopAutoCapture() 
{
	document.getElementById("result").innerHTML = "停止自动连拍";
	var params = "{\"action\": \"stop\"}";// 
	var url = g_strHTTPServerPath + "/video=detectdoc";  	

	if(g_timer != null)
	{
		clearInterval(g_timer);	
		g_timer=null;
	}
	
	$.ajax({  
		type: "post",  
		url: url,  
		dataType: "json", 
		data: params,
		success: function(data)
		{
			document.getElementById("result").innerHTML = "连拍已停止";
		}
		});
}

function GetDocumentStatus()
{
	var params = "{\"action\": \"status\"}";
	var url = g_strHTTPServerPath + "/video=detectdoc";   	
	$.ajax({  
		type: "post",  
		url: url,  
		dataType: "json", 
		data: params,
		success: function(data)
		{				
			if(data.code == "101" && g_iAutoPreCode != data.code)
			{
				document.getElementById("result").innerHTML = "返回代码 = " + data.code + ", 返回信息 = " + data.message + ", 拍摄图像 "; 	
				GrabImage();
			}				
			else if(data.code == "100" || data.code == "102")
			{	
				document.getElementById("result").innerHTML = "返回代码 = " + data.code + ", 返回信息 = " + data.message + ", 请更换文档"; 	
			}
			else if(data.code != "101" && data.code != "0")
			{
				document.getElementById("result").innerHTML = "返回代码 = " + data.code + ", 返回信息 = " + data.message; 	
				if(g_timer != null)
				{
					clearInterval(g_timer);	
					g_timer=null;
				}
			}		
			g_iAutoPreCode = data.code
		}  
		});  
}

/////////////////////////// 合并、清空 ///////////////////////////

function CleanImageList(bShowNullImage)
{
	g_fileList = "";
	document.getElementById("result").innerHTML = "";
	
	if(!bShowNullImage)
		return;
	
	/// 填充空白的示意图
	var strImage = "<img class=\"new_image\" src=\"null_image.png\">";
	var strImages = "";
	for(var i = 0; i < 3; i++)
	{
		strImages += strImage;
	}
	document.getElementById("image_list_div").innerHTML = strImages;
}

function ShowMergedResult(data)
{
	CleanImageList(false);
	if(typeof(data.image) != "undefined")
	{
		AddImageToList(data.image);
		document.getElementById("image_list_div").innerHTML = "<br/>合并结果：<br/>" + document.getElementById("image_list_div").innerHTML;
	}
	else if(typeof(data.filepath) != "undefined")
	{
		var strResult = "<a target=_blank href=\"" + data.filepath + "\">点击此处，查看合并结果</a>";
		document.getElementById("result").innerHTML = strResult;
		document.getElementById("image_list_div").innerHTML = "<br/>" + strResult;
	}
	else
	{
		document.getElementById("result").innerHTML = "显示合并结果错误";
	}
	
	/// 清理掉，下次拍照的时候，会自动清空合并的结果
	g_fileList = "";
}

function MergeImage(iMergeType)
{
	document.getElementById("result").innerHTML = "";
	if (g_fileList == "")
	{
		document.getElementById("result").innerHTML = "图像列表为空";
		return;
	}
	
	var strWatermark = "{ \"pos\":\"4\", \"content\":\"图像水印\", \"transparency\":\"128\", \"fontsize\":\"80\", \"color\":\"red\" }";
	var strStorageInfo = "{ \"xdpi\":\"200\", \"ydpi\":\"200\", \"jpg_quality\":\"60\" }";
	var params = "{\"merge_type\":\"" + iMergeType.toString() + "\", \"margin\":\"5\", \"align\":\"1\", \"make_uuid\":\"0\", \"source_images\":[" + g_fileList + "], \"image_storage_info\":" + strStorageInfo + ", \"watermark\":" + strWatermark + "}";
	var url = g_strHTTPServerPath + "/imagepro=merge_images";

	$.ajax({  
		type: "post",  
		url: url,  
		dataType: "json", 
		data: params,
		success: function(data)
		{
			if(data.code != 0)
			{
				document.getElementById("result").innerHTML = "合并失败，返回代码 = " + data.code + "，返回信息 = " + data.message; 	
			}
			else
			{
				ShowMergedResult(data);
			}  
		}
	});
}

function MergeTB()
{
	MergeImage(1);
}

function MergeLR()
{
	MergeImage(0);
}

function MergeDocument(strDocument)
{
		document.getElementById("result").innerHTML = "";
	if (g_fileList == "")
	{
		document.getElementById("result").innerHTML = "图像列表为空";
		return;
	}
	
	var params = "[" + g_fileList + "]";//
	var url = g_strHTTPServerPath + "/imagepro=merge2" + strDocument;

	$.ajax({
		type: "post",
		url: url,
		dataType: "json",
		data: params,
		success: function(data)
		{
			if(data.code != 0)
			{
				document.getElementById("result").innerHTML = "合并失败，返回代码 = " + data.code + "，返回信息 = " + data.message; 	
			}
			else
			{
				ShowMergedResult(data);
			}
		}
	});

}

function MergePDF()
{
	MergeDocument("pdf");
}

function MergeOFD()
{
	MergeDocument("ofd");
}

/////////////////////////// 设备状态、关闭设备 ///////////////////////////

function GetVideoStatus()
{
	document.getElementById("result").innerHTML = "";
			
	var params = "";
	var url = g_strHTTPServerPath + "/video=status";  	

	$.ajax({  
		type: "post",  
		url: url,  
		dataType: "json", 
		data: params,
		success: function(data)
		{
			if(data.code != 0)
			{
				document.getElementById("result").innerHTML = "获取设备状态失败，返回代码 = " + data.code + "，返回信息 = " + data.message; 	
			}
			else
			{
				document.getElementById("result").innerHTML = "文档摄像头:" + data.video0 + 
																", 人像1:" + data.video1 +
																", 人像2:" + data.video2 + 
																", 红外1:" + data.videoIR1 + 
																", 外红2:" + data.videoIR2;
			}
		}
	});
}

function CloseDevice()
{
	if(g_bIsIE) //ie浏览器
	{
		showVideoOcx.StopPreview();
	}
	else
	{
		var params = "";
		var url = g_strHTTPServerPath + "/video=close&camidx=" + g_iCamIdx.toString();

		$.ajax({  
			type: "post",  
			url: url,  
			dataType: "json", 
			data: params,
			success: function(data)
			{
				document.getElementById("result").innerHTML = data.message;
			}
		});
		//document.getElementById("img_video_preview").src=g_strHTTPServerPath + "/video=close&camidx=" + g_iCamIdx.toString();
	}
}

/////////////////////////// 接口调用测试 ///////////////////////////

function PostToService()
{
	document.getElementById("result").innerHTML = "";
	var params = document.getElementById("para_input").value;
	var url = document.getElementById("url_input").value;  	

	$.ajax({  
		type: "post",  
		url: url,  
		dataType: "json", 
		data: params,
		success: function(data)
		{
			if(data.code != 0)
			{
				document.getElementById("result").innerHTML = "接口请求失败，返回代码 = " + data.code + "，返回信息 = " + data.message; 	
			}
			else
			{
				document.getElementById("result").innerHTML = "接口请求成功";
				if(typeof(data.image) != "undefined")
				{
					AddImageToList(data.image);
				}
				else if(typeof(data.images) != "undefined")
				{
					var images = data.images;
					var iCount = data.image_count;
					for(var i = 0; i < iCount; i++)
						AddImageToList(images[i]);
				}
				else if(typeof(data.filepath) != "undefined")
				{
					var strResult = "<a target=_blank href=\"" + data.filepath + "\">点击查看本地文件</a>";
					document.getElementById("image_list_div").innerHTML = "<br/>" + strResult;
				}
				else
				{
					document.getElementById("result").innerHTML = "接口请求成功，返回内容：" + JSON.stringify(data);
				}
			}
		}
	});
}

//////////////////////////// 录像相关 ////////////////////////////	
	function GetAudioList() {
		document.getElementById("result").innerHTML = "获取音频设备列表... ...";
		
		var params = "{\"action\": \"audio\"}";// 识别区域
		var url = g_strHTTPServerPath + "/video=record"; 

		$.ajax({  
			type: "post",  
			url: url,  
			dataType: "json", 
			data: params,
			success: function(data)
			{				
				if(data.code != 0)
				{
					document.getElementById("result").innerHTML = "获取音频设备列表失败<br />返回代码 = " + data.code + "<br />  返回信息 = " + data.message; 	
				}
				else				
				{
					var select = document.getElementById("audio_list");
					//获取select下拉框下所有的选项
					while(select.options.length > 0)
					{
						select.remove(i);
					}
					
					for(var i=0; i<data.audio.length; i++)
					{
						select.options.add(new Option(data.audio[i], data.audio[i])); 
					}
										
					document.getElementById("result").innerHTML = "获取音频设备列表成功<br />返回代码 = " + data.code; 						
				}  
			}
		});  					
	}	
	
	function GetRecordVideoStatus() {
	
		var params = "{\"action\": \"status\"}";// 
		var url = g_strHTTPServerPath + "/video=record"; 
		

		$.ajax({  
			type: "post",  
			url: url,  
			dataType: "json", 
			data: params,
			success: function(data)
			{				
				if(data.code != 0)
				{
					document.getElementById("result").innerHTML = "获取当前视频录制状态失败，返回代码 = " + data.code + "，返回信息 = " + data.message; 	
				}
				else				
				{		
					if(data.status == 100)
					{
						document.getElementById("result").innerHTML = data.message; 	
					}
					else if(data.status == 101)
					{
						document.getElementById("result").innerHTML = data.message + " " + data.time; 	
					}
					else if(data.status == 102)
					{
						document.getElementById("result").innerHTML = data.message; 	
					}
				}  
			}  
			});  
	}		
	
	function StartRecordVideo_WM() {
		document.getElementById("result").innerHTML = "请求开始视频录制... ...";
		
		var select = document.getElementById("audio_list");
		var index = select.selectedIndex;		
		var text = "";
		if(index >= 0)
			select.options[index].text;
		
		var watermark = "\"watermark\":{\"pos\":\"0\",\"content\":\"测试水印\",\"transparency\":\"250\",\"fontsize\":\"32\",\"font\":\"微软雅黑\",\"color\":\"white\"}";		
		var params = "{\"action\": \"start\", \"parameter\": {\"camidx\": \"1\",\"width\": \"1280\",\"height\": \"720\",\"bit_rate\": \"600000\",\"framerate\": \"15\",\"audio\": \"" + text + "\"," + watermark + "}}";// 
		var url = g_strHTTPServerPath + "/video=record";   

		$.ajax({  
			type: "post",  
			url: url,  
			dataType: "json", 
			data: params,
			success: function(data)
			{				
				if(data.code != 0)
				{
					document.getElementById("result").innerHTML = "视频录制失败<br />返回代码 = " + data.code + "<br />  返回信息 = " + data.message; 	
				}
				else				
				{									
					document.getElementById("result").innerHTML = "开始视频录制<br />返回代码 = " + data.code + "<br />  文件路径 = " + data.filepath; 						
				}  
			}
		});  					
	}
	
	function StartRecordVideo() {
		document.getElementById("result").innerHTML = "请求开始视频录制... ...";
		
		var select = document.getElementById("audio_list");
		var index = select.selectedIndex;		
		var text = "";
		if(index >= 0)
			select.options[index].text;

		
		var params = "{\"action\": \"start\", \"parameter\": {\"camidx\": \"1\",\"width\": \"1280\",\"height\": \"720\",\"framerate\": \"15\",\"audio\": \"" + text + "\"}}";// 
		var url = g_strHTTPServerPath + "/video=record";   

		$.ajax({  
			type: "post",  
			url: url,  
			dataType: "json", 
			data: params,
			success: function(data)
			{				
				if(data.code != 0)
				{
					document.getElementById("result").innerHTML = "视频录制失败<br />返回代码 = " + data.code + "<br />  返回信息 = " + data.message; 	
				}
				else				
				{									
					document.getElementById("result").innerHTML = "开始视频录制<br />返回代码 = " + data.code + "<br />  文件路径 = " + data.filepath; 						
				}  
			}
		});  					
	}
	
	function StopRecordVideo() {
		
		var params = "{\"action\": \"stop\"}";// 
		var url = g_strHTTPServerPath + "/video=record"; 

		$.ajax({  
			type: "post",  
			url: url,  
			dataType: "json", 
			data: params,
			success: function(data)
			{				
				if(data.code != 0)
				{
					document.getElementById("result").innerHTML = "停止视频录制失败<br />返回代码 = " + data.code + "<br />  返回信息 = " + data.message; 	
				}
				else				
				{
										
					document.getElementById("result").innerHTML = "停止视频录制成功 录制时长 " + data.time; 						
				}  
			}
		});  					
	}			
	
/////////////////////////////////----------------/////////////////////////////////
///////////////////////////////// 自定义切边专区 /////////////////////////////////
/////////////////////////////////----------------/////////////////////////////////

var g_startPageX;
var g_startPageY;
var g_startImgX;
var g_startImgY;
var g_bPressed;

function InitForCustomCut()
{
	g_bIsIE = IsIE();
	if(g_bIsIE) //ie浏览器
	{
		var ui = document.getElementById("img_video_preview");
		ui.style.display="none";
		ui.style.visibility="hidden";		
		showVideoOcx.StartPreview(0);
	}
	else
	{
		var ui = document.getElementById("ocx_div");
		ui.style.display="none";
		ui.style.visibility="hidden";
	}
	OpenCamera();
	SetAutoCut(false);
	reset_custom_rect();
	g_iCutType = "2";
	if(g_bIsIE)
	{
		showVideoOcx.SetCustomCut(true);
	}
}

function GetCustomCutPos()
{
	var rect = showVideoOcx.GetCustomCutPos();
	document.getElementById("custom_rect_input").value = rect;
}

function CatchGetCustomCutRect(szPos)
{
	document.getElementById("custom_rect_input").value = szPos;
}

function DetectZoom ()
{ 
	var ratio = 0;
	screen = window.screen;
	ua = navigator.userAgent.toLowerCase();

	if (window.devicePixelRatio !== undefined) 
	{
		ratio = window.devicePixelRatio;
	}
	else if (~ua.indexOf("msie")) 
	{  
		if (screen.deviceXDPI && screen.logicalXDPI) 
		{
			ratio = screen.deviceXDPI / screen.logicalXDPI;
		}
	}
	else if (window.outerWidth !== undefined && window.innerWidth !== undefined) 
	{
		ratio = window.outerWidth / window.innerWidth;
	}

	if (ratio)
		ratio = Math.round(ratio * 100);

	return ratio;
};

function custom_rect_mouse_down(event)
{
	if(g_bPressed)
		return;
	if(event.button != 2)
		return;
	reset_custom_rect();
}

function reset_custom_rect()
{
	document.getElementById("custom_rect").style.visibility = "hidden";
	document.getElementById("custom_rect").style.width = "0px";
	document.getElementById("custom_rect").style.height = "0px";
	
	g_startPageX = 0;
	g_startPageY = 0;
	g_startImgX = 0;
	g_startImgY = 0;
}

function stream_mouse_down(event)
{
	if(g_iCutType != "2")
		return;
	if(event.button != 2)
		return;
	
	var iZoom = DetectZoom();
	if(iZoom != 100)
	{
		alert("浏览器缩放比例(" + iZoom + ")不为100，手动切边无法正常使用");
		return;
	}
	
	document.getElementById("custom_rect").style.position = "absolute";
	document.getElementById("custom_rect").style.left = event.pageX + "px";
	document.getElementById("custom_rect").style.top = event.pageY + "px";
	document.getElementById("custom_rect").style.width = "0px";
	document.getElementById("custom_rect").style.height = "0px";
	document.getElementById("custom_rect").style.border = "3px solid #0000FF";
	document.getElementById("custom_rect").style.visibility = "visible";
	
	var steamElement = document.getElementById("img_video_preview");
	g_startImgX = event.clientX - steamElement.x;
	g_startImgY = event.clientY - steamElement.y;
	
	g_startPageX = event.pageX;
	g_startPageY = event.pageY;
	g_bPressed = true;
}

function mouse_up(event)
{
	g_bPressed = false;
	var rectElement = document.getElementById("custom_rect");
	var steamElement = document.getElementById("img_video_preview");
	var left = g_startImgX / steamElement.width; left *= 100;
	var top = g_startImgY / steamElement.height; top *= 100;
	var right = (g_startImgX + parseInt(rectElement.style.width)) / steamElement.width; right *= 100;
	var bottom = (g_startImgY + parseInt(rectElement.style.height)) / steamElement.height; bottom *= 100;
	
	var jsRect = "{\"left\":\"" + left.toFixed(2) + "%\", \"top\":\"" + top.toFixed(2) + "%\", \"right\":\"" + right.toFixed(2) + "%\", \"bottom\":\"" + bottom.toFixed(2) + "%\"}";
	document.getElementById("custom_rect_input").value = jsRect;
}

function mouse_move(event)
{
	UpdateCustomRect();
}

function UpdateCustomRect()
{
	if(!g_bPressed)
		return;
	var w = event.pageX - g_startPageX;
	var h = event.pageY - g_startPageY;
	document.getElementById("custom_rect").style.width = w + "px";
	document.getElementById("custom_rect").style.height = h + "px";
}

function doNothing()
{  
	window.event.returnValue=false;  
	return false;  
}

function GrabImage_CustomCut()
{
	var jsCustomRect = ", \"custom_rect\":" + document.getElementById("custom_rect_input").value;

	var strStorageInfo = "{ \"xdpi\":\"200\", \"ydpi\":\"200\", \"jpg_quality\":\"60\" }";
	var strImageProcess = "{\"cut_type\":\"" + g_iCutType + "\", \"multi_object\":\"0\", \"rotate\":\"" + g_iAngle.toString() +  "\"" + jsCustomRect + "}";
	var params = "{\"camidx\":\"" + g_iCamIdx.toString() + "\",\"make_uuid\":\"1\",\"image_storage_info\":" + strStorageInfo + ",\"image_process_info\":" + strImageProcess + "}";

	var url = g_strHTTPServerPath + "/video=grabimage";

	$.ajax({
		type: "post",
		url: url,
		dataType: "json",
		data: params,
		success: function(data)
		{
			if(data.code != 0)
			{
				document.getElementById("result").innerHTML = "拍照失败，错误代码：" + data.code + "，返回信息 = " + data.message;
			}
			else
			{
				document.getElementById("result").innerHTML = "图像数量：" + data.image_count;
				var images = data.images;
				var iCount = data.image_count;
				var strImageList = "";
				for(var i = 0; i < iCount; i++)
				{
					AddImageToList(data.images[i]);
				}
			}
		}
	});
}

	function Barcode() {
		document.getElementById("result").innerHTML = "条码识别中 ... ... ";
		var params = "{\"roi\": {\"top\":\"0\",\"left\":\"0\",\"bottom\":\"1\",\"right\":\"1\"}, \"cutpage\":\"" + (g_iCutType == "1" ? 1 : 0) + "\", \"binary\":\"0\",\"rotate\":\"" + g_iAngle.toString() + "\"}";// 识别区域
		var url = g_strHTTPServerPath + "/imagepro=barcode";  	

		$.ajax({  
			type: "post",
			url: url,
			dataType: "json",
			data: params,
			success: function(data)
			{
				if(data.code != 0)
				{
					document.getElementById("result").innerHTML = "条码识别失败<br />返回代码 = " + data.code + "<br />  返回信息 = " + data.message; 	
				}
				else
				{
					var barcode = "";
					for(var i = 0; i < data.barcode.length; i++)
					{
						barcode += "条码" + i.toString() + "，类型：" + data.barcode[i].type + "，条码：" + data.barcode[i].code + "<br />";
					}
					document.getElementById("result").innerHTML = "条码个数 = " + data.count.toString() + "<br />" + barcode;
				}  
			}
		});  					
	}


	function sleep(delay) {
		var start = (new Date()).getTime();
		while ((new Date()).getTime() - start < delay) {
		continue;
		}
	}
	var setFocusTimes; 
	function SetFocusValue(value)  {
		var params = "{\"camidx\": \"" + g_iCamIdx.toString() + "\",\"focus\":\"" + value.toString() + "\"}";// 识别区域
		var url = g_strHTTPServerPath + "/video=setproperty";  	

		$.ajax({  
			type: "post",
			url: url,
			dataType: "json",
			data: params,
			success: function(data)
			{
				if(data.code != 0)
				{
					document.getElementById("result").innerHTML = "自动对焦失败<br />返回代码 = " + data.code + "<br />  返回信息 = " + data.message; 	
				}
				else
				{
					setFocusTimes++;
					if(setFocusTimes == 2){
						document.getElementById("result").innerHTML = "自动对焦完成";
					}
				}  
			}
		}); 
	}
	function TriggerAutoFocus()  {
		document.getElementById("result").innerHTML = "自动对焦中 ... ... ";
				var params = "{\"camidx\": \"" + g_iCamIdx.toString() + "\",\"key\":\"focus\"}";// 识别区域
		var url = g_strHTTPServerPath + "/video=getproperty";  	

		$.ajax({  
			type: "post",
			url: url,
			dataType: "json",
			data: params,
			success: function(data)
			{
				if(data.code != 0 || data.settable == 1)
				{
					document.getElementById("result").innerHTML = "自动对焦失败<br />返回代码 = " + data.code + "<br />  返回信息 = " + data.message; 	
				}
				else
				{
					setFocusTimes = 0;
					SetFocusValue(data.default);
					sleep(500);
					SetFocusValue(data.max + 1);
				}  
			}
		}); 
	}
