var g_strHTTPServerPath = "http://127.0.0.1:38088";
var g_strWebsocketServerPath = "ws://127.0.0.1:38088";
