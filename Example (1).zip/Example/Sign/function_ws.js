var websocket;
var connected = false;

/**
 * 初始化webSocket连接
 * @param callback
 * @param value
 * @constructor
 */
function ConnectServer(callback, value) {

    if ("WebSocket" in window) {
        websocket = new WebSocket(g_strWebsocketServerPath);
    } else if (window.WebSocket) {
        websocket = new WebSocket(g_strWebsocketServerPath);
    } else if ("MozWebSocket" in window) {
        websocket = new MozWebSocket(g_strWebsocketServerPath);
    } else {
        alert("浏览器版本太低！请使用Chrome、Firefox、IE10+浏览器！");
    }

    websocket.onopen = function () {
        connected = true;
        callback(value);
    }
    websocket.onclose = function (e) {
        connected = false;
    }
    websocket.onmessage = function (e) {
        onMessage(e);
    }
    websocket.onerror = function (e) {
        alert("未连接websocket服务器，请确保已运行服务端！!!!");
    };
}

/**
 * 接收服务器消息
 * @param e
 */
function onMessage(e) {
	var jsonObj =JSON.parse(e.data);
	
	if(jsonObj.function == "start_sign")
	{
		if(jsonObj.code != 0)
		{
			document.getElementById("result").innerHTML = "打开签字窗口失败<br />返回代码 = " + jsonObj.code + "<br />  返回信息 = " + jsonObj.message; 	
		}
		else
		{
			document.getElementById("result").innerHTML = "打开签字窗口成功，请在签字窗口内签字"; 	
		}
	}
	
	if(jsonObj.function == "get_sign_image")
	{
		if(jsonObj.code == 0)
		{
			document.getElementById("photo").src= "data:image/gif;base64," + jsonObj.image;
		}
		else if(jsonObj.code == 1)
		{				
			document.getElementById("result").innerHTML = "未获取到签字图像"; 	
		}
		else
		{
			document.getElementById("result").innerHTML = "打开签字窗口失败<br />返回代码 = " + jsonObj.code + "<br />  返回信息 = " + jsonObj.message; 	
		}		
	}
	
	if(jsonObj.function == "get_sign_status")
	{
		if(jsonObj.code == 0)
		{
			if(jsonObj.status == 2)
			{
				document.getElementById("result").innerHTML = "获取签字笔迹图像";
				GetSignImage();
			}
			else
			{
				document.getElementById("result").innerHTML = "等待用户签字确认中 ... ..." + "(" + jsonObj.status + ")";
			}
		}
		else
		{
			document.getElementById("result").innerHTML = "打开签字窗口失败<br />返回代码 = " + jsonObj.code + "<br />  返回信息 = " + jsonObj.message; 
		}		
	} 	
	
	if(jsonObj.function == "show_browser")
	{
		if(jsonObj.code != 0)
		{
			document.getElementById("result").innerHTML = "打开网页预览窗口失败<br />返回代码 = " + jsonObj.code + "<br />  返回信息 = " + jsonObj.message; 	
		}
		else
		{
			document.getElementById("result").innerHTML = "打开网页预览窗口成功"; 
			//EnableMouseMode();
		}
	}  	
	
	if(jsonObj.function == "close_browser")
	{
		DisableMouseMode();
	} 


	if(jsonObj.function == "enable_sign_screen_mouse")
	{
		if(jsonObj.code != 0)
		{
			document.getElementById("result").innerHTML = "鼠标模式设置失败<br />返回代码 = " + jsonObj.code + "<br />  返回信息 = " + jsonObj.message; 	
		}
	} 
	
	if(jsonObj.function == "show_evaluator")
	{
		if(jsonObj.code != 0)
		{
			document.getElementById("result").innerHTML = "显示评价窗口失败<br />返回代码 = " + jsonObj.code + "<br />  返回信息 = " + jsonObj.message; 	
		}
		else
		{
			document.getElementById("result").innerHTML = "显示评价窗口成功"; 
		}		
	} 	
	
	if(jsonObj.function == "close_evaluator")
	{
		if(jsonObj.code != 0)
		{
			document.getElementById("result").innerHTML = "关闭评价窗口失败<br />返回代码 = " + jsonObj.code + "<br />  返回信息 = " + jsonObj.message; 	
		}
	}	
	
	if(jsonObj.function == "evaluator_result" || jsonObj.function == "get_evaluator_result")
	{
		if(jsonObj.code == 0)
		{
			document.getElementById("result").innerHTML = "评价结果：" + "(" + jsonObj.result + ")";
			CloseEvaluator();
		}
		else if(jsonObj.code == 1)
		{
			document.getElementById("result").innerHTML = "等待用户评价 ... ...";
		}
		else
		{
			document.getElementById("result").innerHTML = "打开签字窗口失败<br />返回代码 = " + jsonObj.code + "<br />  返回信息 = " + jsonObj.message; 	
			CloseEvaluator();
		}
	}			
}

/**
 * 向服务器发送信息的共享方法
 * @param jsonStr
 */
function sendMessage(jsonStr) {
    connected ? websocket.send(jsonStr) : alert("未连接websocket服务器，请确保已运行服务端！");
}


	//初始化
function Init(){
	
	document.getElementById("sign_window_pos").value = "{\"left\":\"180\",\"top\":\"120\",\"width\":\"920\",\"height\":\"560\"}";
	document.getElementById("valid_sign_rect").value = "{\"left\":\"0%\",\"top\":\"0%\",\"right\":\"100%\",\"bottom\":\"100%\"}";
	document.getElementById("sign_buttons_info").value = "[\n{\"button_name\":\"sign_ok_button\", \"text\":\"确认\", \"visible\":\"1\"},\n{\"button_name\":\"sign_reset_button\", \"text\":\"重签\", \"visible\":\"1\"}\n]";
	
	document.getElementById("result").innerHTML = "等待用户操作";	
}

function Release()
{

}

function StartSign() {

	document.getElementById("result").innerHTML = "打开签字窗口......";
	document.getElementById("photo").src= "";
	var pos = document.getElementById("sign_window_pos").value;
	var valid_sign_rect = document.getElementById("valid_sign_rect").value;
	var sign_buttons_info = document.getElementById("sign_buttons_info").value;
	var opacity = document.getElementById("sign_window_opacity").value;
	var background_image = document.getElementById("sign_window_background").value;
	var background_image_base64 = document.getElementById("sign_window_background_base64").value;
	var image_type = document.getElementById("image_type").value;
	var params = "{\"pos\": " + pos + ", \"valid_sign_rect\": " + valid_sign_rect + ", \"sign_buttons_info\": " + sign_buttons_info + ", \"opacity\":\"" + opacity + "\", \"background_image\":{\"filepath\":\"" + background_image + "\", \"image_type\":\"" + image_type + "\", \"base64\":\"" + background_image_base64 + "\"} }";
	
	var data = "{\"function\": \"start_sign\", \"params\": " + params + "}";	
    connected ? sendMessage(data) : ConnectServer(sendMessage, data);	
}

function StopSign() {

	document.getElementById("result").innerHTML = "关闭签字窗口";
	var params = "\"\"";// 
	
	var data = "{\"function\": \"stop_sign\", \"params\": " + params + "}";
    connected ? sendMessage(data) : ConnectServer(sendMessage, data);	
			
	if(timerStatus != null)
	{
		clearInterval(timerStatus);	
		timerStatus=null;
	}
}

function GetSignImage() {

	document.getElementById("result").innerHTML = "获取签字笔迹图像";
	var params = "\"\"";// 
	
	var data = "{\"function\": \"get_sign_image\", \"params\": " + params + "}";
    connected ? sendMessage(data) : ConnectServer(sendMessage, data);			
}

function GetSignStatus() {
	document.getElementById("result").innerHTML = "获取签字笔迹图像";
	var params = "\"\"";// 
	
	var data = "{\"function\": \"get_sign_status\", \"params\": " + params + "}";
    connected ? sendMessage(data) : ConnectServer(sendMessage, data);			
}

function ShowWebBrowser() {

	var g_strWebsocketServerPath = document.getElementById("g_strWebsocketServerPath_input").value;
	if(g_strWebsocketServerPath == "")
	{
		g_strWebsocketServerPath = "www.baidu.com";
	}
	document.getElementById("result").innerHTML = "打开网页预览窗口: " + g_strWebsocketServerPath;
	var params = "{\"g_strWebsocketServerPath\": \"" + g_strWebsocketServerPath + "\"}";// 
	
	var data = "{\"function\": \"show_browser\", \"params\": " + params + "}";
    connected ? sendMessage(data) : ConnectServer(sendMessage, data);				
}

function CloseWebBrowser() {

	document.getElementById("result").innerHTML = "关闭网页预览窗口";
	var params = "\"\"";// 
	
	var data = "{\"function\": \"close_browser\", \"params\": " + params + "}";
    connected ? sendMessage(data) : ConnectServer(sendMessage, data);	 
}

function EnableMouseMode() {
	var params = "{\"enable_sign_screen_mouse\": true}";// 
	
	var data = "{\"function\": \"enable_sign_screen_mouse\", \"params\": " + params + "}";
    connected ? sendMessage(data) : ConnectServer(sendMessage, data);	
}

function DisableMouseMode() {
	var params = "{\"enable_sign_screen_mouse\": false}";// 
	
	var data = "{\"function\": \"enable_sign_screen_mouse\", \"params\": " + params + "}";
    connected ? sendMessage(data) : ConnectServer(sendMessage, data);		 
}

function ShowEvaluator() {
	
	document.getElementById("result").innerHTML = "显示评价窗口";
	//var params = "{\"pos\": {\"top\": \"200\",\"left\": \"340\",\"width\": \"600\",\"height\": \"400\"}, \"tip_message\": {\"content\": \"请对当前服务人员进行评价\",\"fontsize\": \"20\",\"textcolor\": \"0xFF0000\",\"backgroundcolor\": \"0xFFFFFF\"}, \"buttons\": [{\"content\": \"特别好\",\"fontsize\": \"12\",\"textcolor\": \"0x000000\",\"buttoncolor\": \"0xFF0000\",\"icon\": \"0\"},{\"content\": \"还行吧\",\"fontsize\": \"12\",\"textcolor\": \"0x000000\",\"buttoncolor\": \"0xFFFFFF\",\"icon\": \"1\"},{\"content\": \"嘚瑟\",\"fontsize\": \"12\",\"textcolor\": \"0x00FF00\",\"buttoncolor\": \"0xFF0000\",\"icon\": \"D:/Sign.png\"},{\"content\": \"你说啥\",\"fontsize\": \"12\",\"textcolor\": \"0x000000\",\"buttoncolor\": \"0xFF0000\",\"icon\": \"D:/1.jpg\"}]}";  
	var params = "\"\"";// 
	
	var data = "{\"function\": \"show_evaluator\", \"params\": " + params + "}";
    connected ? sendMessage(data) : ConnectServer(sendMessage, data);	
}


function CloseEvaluator() {
	
	var params = "\"\"";// 
	
	var data = "{\"function\": \"close_evaluator\", \"params\": " + params + "}";
    connected ? sendMessage(data) : ConnectServer(sendMessage, data);		  
}

function GetEvaluatorResult() {
	
	var params = "\"\"";// 
	
	var data = "{\"function\": \"get_evaluator_result\", \"params\": " + params + "}";
    connected ? sendMessage(data) : ConnectServer(sendMessage, data);	
}

/////////////////////////////////////////////////////////////////////////////////////////////////

function GetSignScreenPos() {

	document.getElementById("result").innerHTML = "获取签字屏位置";
	var params = "{\"type\": \"screen_pos\"}";
	var data = "{\"function\": \"get_screen_pos\", \"params\": " + params + "}";	
    connected ? sendMessage(data) : ConnectServer(sendMessage, data);	
}

function ShowFloatingButtonGroup() {

	document.getElementById("result").innerHTML = "显示评价窗口";
	// var params = "{\"pos\": {\"top\": \"200\",\"left\": \"340\",\"width\": \"600\",\"height\": \"400\"}, \"buttons\": [{\"content\": \"特别好\",\"fontsize\": \"12\",\"textcolor\": \"0x000000\",\"buttoncolor\": \"0xFF0000\",\"icon\": \"0\"},{\"content\": \"还行吧\",\"fontsize\": \"12\",\"textcolor\": \"0x000000\",\"buttoncolor\": \"0xFFFFFF\",\"icon\": \"1\"},{\"content\": \"嘚瑟\",\"fontsize\": \"12\",\"textcolor\": \"0x00FF00\",\"buttoncolor\": \"0xFF0000\",\"icon\": \"D:/Sign.png\"},{\"content\": \"你说啥\",\"fontsize\": \"12\",\"textcolor\": \"0x000000\",\"buttoncolor\": \"0xFF0000\",\"icon\": \"D:/1.jpg\"}]}"; 
	var params = "";
	var data = "{\"function\": \"show_floating_button_group\", \"params\": " + params + "}";	
    connected ? sendMessage(data) : ConnectServer(sendMessage, data);	
}

function CloseFloatingButtonGroup() {

	var params = "";// 
	var data = "{\"function\": \"close_floating_button_group\", \"params\": " + params + "}";	
    connected ? sendMessage(data) : ConnectServer(sendMessage, data);	
}

function GetFloatingButtonGroupResult() {
	document.getElementById("result").innerHTML = "获取按钮结果";
	var params = "";// 
	var data = "{\"function\": \"get_floating_button_group_result\", \"params\": " + params + "}";	
    connected ? sendMessage(data) : ConnectServer(sendMessage, data);	
}


/////////////////////////// 初始化、卸载 ///////////////////////////

function OpenCamera()
{
	var camradio = document.getElementsByName("camidx");
	for(i=0; i<camradio.length; i++)
	{
		if(camradio[i].checked)
			g_iCamIdx = camradio[i].value;
	}	

	var data = "{\"function\": \"open_camera\", \"camidx\": \"" + g_iCamIdx.toString() + "\"}";
    connected ? sendMessage(data) : ConnectServer(sendMessage, data);
	
	setTimeout( function(){
		GetResolutionList();
	}, 1000 );//延迟1000毫秒		
}

function CloseDevice()
{
	var data = "{\"function\": \"close_camera\", \"camidx\": \"" + g_iCamIdx.toString() + "\"}";
    connected ? sendMessage(data) : ConnectServer(sendMessage, data);
}

function GrabImage()
{
	var strStorageInfo = "{ \"xdpi\":\"200\", \"ydpi\":\"200\", \"jpg_quality\":\"60\" }";
	var strImageProcess = "{\"cut_type\":\"" + g_iCutType + "\", \"multi_object\":\"0\", \"rotate\":\"" + g_iAngle.toString() +  "\"}";
	var params = "{\"camidx\":\"" + g_iCamIdx.toString() + "\",\"make_uuid\":\"1\",\"image_storage_info\":" + strStorageInfo + ",\"image_process_info\":" + strImageProcess + "}";
	
	var data = "{\"function\": \"grab_image\", \"params\": " + params + "}";
    connected ? sendMessage(data) : ConnectServer(sendMessage, data);
}

/////////////////////////// 分辨率 ///////////////////////////

function GetResolutionList()
{
	var params = "{\"type\": \"resolution\",\"camidx\":\"" + g_iCamIdx.toString() + "\"}";
	
	var data = "{\"function\": \"get_resolution\", \"params\": " + params + "}";
    connected ? sendMessage(data) : ConnectServer(sendMessage, data);	

}

function SetResolution()
{
		var select = document.getElementById("resolution");
		var index = select.selectedIndex;		
		var text = select.options[index].text
		var splits = text.split("x");
		
		var params = "{\"resolution\": {\"width\":\"" + splits[0] + "\",\"height\":\"" + splits[1] + "\"},\"camidx\":\"" + g_iCamIdx.toString() + "\"}";
		
		var data = "{\"function\": \"set_resolution\", \"params\": " + params + "}";		
		
		connected ? sendMessage(data) : ConnectServer(sendMessage, data);
}	
