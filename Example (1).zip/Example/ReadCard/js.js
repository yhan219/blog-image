
var office = 0;
var g_strDefaultDocumentFile = "/tmp/records.et";

function ShowStatus(str)
{
	document.getElementById("status_text").innerHTML = str;
}
function GetSAMId()
{
	var params = "";
	var url = g_strHTTPServerPath + "/card=getsamid";  	
	$.ajax({  
		type: "post",  
		url: url,  
		dataType: "json", 
		data: params,
		success: function(data)
		{
			if(data.code == 0)
			{
                var tmp = document.getElementById("result_text").innerHTML;
                document.getElementById("result_text").innerHTML = tmp + "<br />模块号：" + data.samID;
			}
			else
			{
				alert("获取模块号失败" + data.code);
			}
        }
		}); 
}

function ReadIDCard()
{
    ShowStatus("二代证信息读取中......");
	var params = "";
	var url = g_strHTTPServerPath + "/card=idcard";  	

	$.ajax({  
		type: "post",  
		url: url,  
		dataType: "json", 
		data: params,
		success: function(data)
		{
			if(data.code != 0)
			{
                document.getElementById("result_text").innerHTML =
                                                                         "姓名：" +
                                                                         "<br />性别：" +
                                                                         "<br />生日：" +
                                                                         "<br />地址：" +
                                                                         "<br />身份证号：" +
                                                                         "<br />发卡机构：" +
                                                                         "<br />有效时间：";
                document.getElementById("card_photo").src= "image/idcard_photo.png";
                ShowStatus("读卡失败:" + data.code + ", " + data.message);
			}
			else
			{
                document.getElementById("result_text").innerHTML =
                                                                         "姓名：" + data.IDCardInfo.name +
																		 "<br />性别：" + data.IDCardInfo.sex +
																		 "<br />生日：" + data.IDCardInfo.birthday +
																		 "<br />地址：" + data.IDCardInfo.address +
																		 "<br />身份证号：" + data.IDCardInfo.cardID +
																		 "<br />发卡机构：" + data.IDCardInfo.issueOrgan + 
																		 "<br />有效时间：" + data.IDCardInfo.validStart + "-" + data.IDCardInfo.validEnd;
				document.getElementById("card_photo").src= "data:image/gif;base64," + data.IDCardInfo.photoBase64;
                ShowStatus("读取成功");
				GetSAMId();
			}
        }
		});  
}

function ReadSocialCard() {

	ShowStatus("社保卡信息读取中......");
	document.getElementById("card_photo").src= "image/idcard_photo.png";
	var params = "";
	var url = g_strHTTPServerPath + "/card=sociaseceritycard";  	

	$.ajax({  
		type: "post",  
		url: url,  
		dataType: "json", 
		data: params,
		success: function(data)
		{
			if(data.code != 0)
			{
				document.getElementById("result_text").innerHTML = "";
				ShowStatus("读卡失败:" + data.code + ", " + data.message);
			}
			else
			{
				document.getElementById("result_text").innerHTML = 
																		 "社保号：" + data.SocialCardInfo.SocialSecurityNumber +
																		 "<br />姓名：" + data.SocialCardInfo.Name + 	
																		 "<br />性别：" + data.SocialCardInfo.Sex +
																		 "<br />民族：" + data.SocialCardInfo.Nation +
																		 "<br />生日：" + data.SocialCardInfo.Birthday +
																		 "<br />出生地：" + data.SocialCardInfo.Birthplace +
																		 "<br />卡识别码：" + data.SocialCardInfo.CardDistinguishCode +
																		 "<br />卡类别：" + data.SocialCardInfo.SocialSecurityCardType + 
																		 "<br />卡规范版本：" + data.SocialCardInfo.CardNormVer +
																		 "<br />签证机关：" + data.SocialCardInfo.VisaInstitution + 
																		 "<br />有效时间：" + data.SocialCardInfo.ValidStart + "-" + data.SocialCardInfo.ValidEnd +
																		 "<br />卡号：" + data.SocialCardInfo.CardNumber;
				ShowStatus("读取成功");
			}
		}  
		});  
}

function ReadICCard()
{
	ShowStatus("IC卡信息读取中......");
	document.getElementById("card_photo").src= "image/idcard_photo.png";
	var params = "";
	var url = g_strHTTPServerPath + "/card=iccard";

	$.ajax({  
		type: "post",  
		url: url,  
		dataType: "json", 
		data: params,
		success: function(data)
		{
			if(data.code != 0)
			{
				document.getElementById("result_text").innerHTML = "";
				ShowStatus("读卡失败:" + data.code + ", " + data.message);
			}
			else
			{
				document.getElementById("result_text").innerHTML = 
																		 "卡号: " + data.ICCardInfo.CardNumber +
																		 "<br />卡类型: " + data.cardType +
																		 "<br />姓名: " + data.ICCardInfo.Name + 	
																		 "<br />证件类型: " + data.ICCardInfo.CertificatesType +
																		 "<br />证件号码: " + data.ICCardInfo.CertificatesNo +
																		 "<br />余额: " + data.ICCardInfo.Balance + 
																		 "<br />余额上限: " + data.ICCardInfo.BalanceLimit +
																		 "<br />单笔交易限额: " + data.ICCardInfo.SingleTradingLimit +
																		 "<br />应用货币代码: " + data.ICCardInfo.TransactionCurrencyCode + 
																		 "<br />失效日期: " + data.ICCardInfo.ExpiryDate +
																		 "<br />IC卡序列号: " + data.ICCardInfo.SerialNumber +
																		 "<br />一磁道信息: " + data.ICCardInfo.Track1 +
																		 "<br />二磁道信息: " + data.ICCardInfo.Track2 +
																		 "<br />三磁道信息: " + data.ICCardInfo.Track3 +
																		 "<br />当前IC卡的AID: " + data.ICCardInfo.IcCardAID
																		 ;
				//ShowStatus("读取成功");
				ShowStatus("");
			}
		}  
		});  

}

function ReadMagCard()
{
	ShowStatus("磁条卡信息读取中......");
	document.getElementById("card_photo").src= "image/idcard_photo.png";
	var params = "";
	var url = g_strHTTPServerPath + "/card=magcard";

	$.ajax({  
		type: "post",  
		url: url,  
		dataType: "json", 
		data: params,
		success: function(data)
		{
			if(data.code != 0)
			{
				document.getElementById("result_text").innerHTML = "";
				ShowStatus("读卡失败:" + data.code + ", " + data.message);
			}
			else
			{
				document.getElementById("result_text").innerHTML = 
																		 "磁道1: " + data.MagCardInfo.Track1 +
																		 "<br />磁道2: " + data.MagCardInfo.Track2 + 	
																		 "<br />磁道3: " + data.MagCardInfo.Track3;
				//ShowStatus("读取成功");
				ShowStatus("");
			}
		}  
		});  
}


